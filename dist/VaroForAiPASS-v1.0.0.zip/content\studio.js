// Varo Studio — in-page slide-in panel (right side). Uses Shadow DOM so the
// panel's CSS is fully isolated from de.aipass.net. Opens prefilled from the
// bubble / hover overlay / action bar, lets the user tweak prompt + model, then
// generates via the service worker and shows the result inline. Non-blocking:
// the chat stays usable while a job runs.
//
// window.VaroStudio.open({ kind, prompt, imageUrl }) — kind = image|video|audio

(function () {
  // Returns false once the extension is reloaded while this old content script is
  // still alive — guards chrome.* calls so the panel fails quietly (no throws).
  const extAlive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };

  // Verified against api.varoriya.com OpenAPI (2026-09-01). Each model carries
  // its own capabilities so the form only shows options that model supports.
  const MODELS = {
    image: [
      { id: "seedream5pro", label: "Seedream 5 Pro", desc: "แก้แม่นยำ รองรับไทย", ref: true,
        qualities: ["1K", "2K"], aspects: ["auto", "1:1", "16:9", "9:16", "4:3", "3:4"] },
      { id: "nanobananapro", label: "Nano Banana Pro", desc: "1K–4K ข้อความไทยแม่น ค้น Google ได้", ref: true,
        qualities: ["1K", "2K", "4K"], aspects: ["auto", "1:1", "16:9", "9:16", "4:3", "3:4"] },
      { id: "grok", label: "Grok", desc: "หลายสไตล์ ข้อความในภาพคมชัด แก้ได้ 1 รูป", ref: true,
        aspects: ["1:1", "16:9", "9:16", "4:3", "3:4"] },
      { id: "gptimage", label: "GPT-Image", desc: "ทำตามคำสั่งดี ข้อความไทยในภาพ", ref: true,
        qualities: ["low", "medium", "high"], dq: "medium", aspects: ["1:1", "2:3", "3:2"] },
      { id: "z-image", label: "Z-Image", desc: "เร็ว ประหยัด ภาพเหมือนจริง", ref: false,
        qualities: ["1K", "2K", "Sketch"], aspects: ["1:1", "16:9", "9:16", "4:3", "3:4", "21:9", "9:21"] }
    ],
    video: [
      { id: "h3", label: "MiniMax H3", desc: "วิดีโอมีเสียง อ้างอิงรูป/วิดีโอ/เสียง 4–15 วิ", ref: true,
        qualities: ["768P", "2K"], aspects: ["auto", "16:9", "9:16", "1:1", "4:3", "3:4", "21:9"], durations: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] },
      { id: "seedance2", label: "Seedance 2.0", desc: "วิดีโอมีเสียง อ้างอิงรูป/วิดีโอ 4–15 วิ", ref: true,
        qualities: ["480p", "720p"], aspects: ["16:9", "9:16", "1:1", "4:3", "3:4", "21:9"], durations: [4, 5, 6, 8, 10, 12, 15] },
      { id: "grokvideo", label: "Grok Video", desc: "T2V/I2V มีเสียง — v1.5 พูดไทยได้", ref: true,
        qualities: ["480p", "720p"], aspects: ["16:9", "9:16"], durations: [5, 10, 15] },
      { id: "flux3", label: "Flux 3", desc: "วิดีโอมีเสียง keyframe/ต่อคลิป 5–20 วิ", ref: true,
        qualities: ["720p", "1080p"], aspects: ["auto", "16:9", "9:16", "1:1", "4:3", "3:4", "21:9", "2:1"], durations: [5, 10, 15, 20] },
      { id: "wanoptimizet2v", label: "WAN 2.2 · ข้อความ→วิดีโอ", desc: "ถูก/เร็ว ฟิลเตอร์เบา ไม่มีเสียง", ref: false,
        qualities: ["480p", "720p"], aspects: ["16:9", "9:16"] },
      { id: "wanoptimize", label: "WAN 2.2 · รูป→วิดีโอ", desc: "ต้องมีรูปต้นแบบ ฟิลเตอร์เบา ไม่มีเสียง", ref: true,
        qualities: ["480p", "720p"], aspects: ["16:9", "9:16"] }
    ],
    audio: [
      { id: "seedaudio", label: "Seed Audio (รองรับหลายภาษารวมเสียงพูดไทย)",
        desc: "เสียงพูด/ดนตรี/เสียงประกอบ", ref: false }
    ]
  };

  // More Varo services — send the image to generate on varoriya.com (no REST yet).
  const WEB_EDITS = [
    { a: "boxes", icon: "crop_free", label: "Boxes" },
    { a: "reface", icon: "add_reaction", label: "Reface" },
    { a: "retouch", icon: "auto_fix_high", label: "Retouch" },
    { a: "spyshot", icon: "domino_mask", label: "SpyShot" },
    { a: "vr360", icon: "vrpano", label: "VR 360°" },
    { a: "registry", icon: "verified", label: "Registry" }
  ];

  // Starter prompt templates per kind — help newcomers get a good first result.
  const TEMPLATES = {
    image: [
      { label: "ภาพสินค้า", text: "ภาพถ่ายสินค้าระดับโฆษณา วางบนพื้นหลังสตูดิโอสะอาดตา แสงนุ่มมืออาชีพ คมชัดสูง" },
      { label: "พอร์ตเทรต", text: "ภาพพอร์ตเทรตบุคคล แสงสตูดิโอนุ่มนวล พื้นหลังละลาย โทนสีอบอุ่น สมจริง" },
      { label: "โลโก้/แบรนด์", text: "โลโก้มินิมอลทันสมัย เส้นสะอาด พื้นหลังเรียบ เหมาะทำแบรนด์" },
      { label: "การ์ตูน/อนิเมะ", text: "ภาพสไตล์อนิเมะ สีสดใส เส้นคมชัด องค์ประกอบภาพน่ารัก" }
    ],
    video: [
      { label: "ทำให้ภาพเคลื่อนไหว", text: "ทำให้ภาพนี้เคลื่อนไหวอย่างเป็นธรรมชาติ กล้องค่อย ๆ เคลื่อนเข้า แสงนุ่มนวล" },
      { label: "ตัวละครพูดไทย", text: "ผู้หญิงในภาพยิ้มแล้วหันมาทางกล้อง ตัวละครพูดภาษาไทยว่า \"สวัสดีค่ะ ยินดีต้อนรับสู่ Varoriya\" ปากขยับตรงตามเสียง แสงสตูดิโอนุ่มนวล" },
      { label: "โฆษณาสินค้า", text: "วิดีโอโฆษณาสินค้า มุมกล้องหมุนรอบสินค้า แสงสตูดิโอ พื้นหลังสะอาด" },
      { label: "ซีนภาพยนตร์", text: "ซีนภาพยนตร์บรรยากาศดราม่า กล้องเคลื่อนช้า โทนสีซีเนมาติก" }
    ],
    audio: [
      { label: "พากย์ไทย + เอฟเฟกต์", text: "[เสียงผู้หญิงอายุ 18 ปี กำลังวิ่งหอบเหนื่อยอย่างหนัก ท่ามกลางสมรภูมิรบ มีเสียงระเบิดดังตูมสนั่นจนพื้นดินสะเทือน ตามด้วยเสียงปืนกลยิงสาดเข้ามาอย่างต่อเนื่อง] พูดภาษาไทยว่า: \"รู้ไหมว่า Seed Audio 1.0 รองรับเสียงพูดภาษาไทยแล้วนะ! (เสียงระเบิดดังแทรก)\"" },
      { label: "เสียงบรรยาย", text: "เสียงหญิงสาว บรรยายโทนอบอุ่น จังหวะสม่ำเสมอ เหมาะกับสารคดี พูดภาษาไทยว่า \"ณ ผืนป่าอันเงียบสงบแห่งนี้ ชีวิตนับพันกำลังเริ่มต้นขึ้นอีกครั้ง\"" },
      { label: "ดนตรีประกอบ", text: "ดนตรีประกอบบรรยากาศสดใส จังหวะกลาง เหมาะเป็นพื้นหลังคลิป" }
    ]
  };

  const state = { kind: "image", imageUrl: null, jobId: null, pref: {}, coins: null, pricing: [] };
  let host, shadow, els = {};

  chrome.storage?.local.get(["varo_pref_models"], (d) => {
    if (d?.varo_pref_models) state.pref = d.varo_pref_models;
  });

  function fontUrl() {
    return chrome.runtime.getURL("fonts/MaterialSymbolsOutlined.woff2");
  }

  function build() {
    host = document.createElement("div");
    host.id = "varo-studio-host";
    shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        @font-face{font-family:"Varo Material Symbols";font-style:normal;font-weight:100 700;src:url("${fontUrl()}") format("woff2");}
        :host{ all: initial; }
        *{ box-sizing:border-box; font-family:"Segoe UI","Sarabun",system-ui,sans-serif; }
        .sym{ font-family:"Varo Material Symbols"; font-size:18px; line-height:1; vertical-align:middle; }
        .panel{
          position:fixed; top:0; right:0; height:100vh; width:390px; max-width:94vw;
          background:#fff; color:#1f2430; z-index:2147483640;
          box-shadow:-8px 0 30px rgba(17,24,39,.18);
          transform:translateX(105%); transition:transform .28s cubic-bezier(.4,0,.2,1);
          display:flex; flex-direction:column; border-left:3px solid #ff6a00;
        }
        :host(.open) .panel{ transform:translateX(0); }
        header{ display:flex; align-items:center; gap:10px; padding:14px 16px; border-bottom:1px solid #eef1f6; }
        header img{ width:24px; height:24px; border-radius:6px; }
        header .t{ font-weight:700; }
        header .s{ font-size:11px; color:#8a8fa0; }
        header .close{ margin-left:auto; cursor:pointer; color:#8a8fa0; background:none; border:none; }
        header .close:hover{ color:#e85d00; }
        .coins{ display:inline-flex; align-items:center; gap:4px; margin-left:auto; font-size:12px; font-weight:600; color:#e85d00; background:#fff3ea; border:1px solid #ffd9bd; border-radius:20px; padding:4px 10px; }
        .coins .sym{ font-size:15px; }
        header .close{ margin-left:8px; }
        .body{ padding:14px 16px; overflow-y:auto; flex:1; }
        .seg{ display:flex; gap:6px; margin-bottom:12px; }
        .seg button{ flex:1; padding:8px; border:1px solid #e7eaf0; background:#fff; border-radius:9px; cursor:pointer; font-size:13px; display:flex; align-items:center; justify-content:center; gap:5px; color:#1f2430; }
        .seg button.on{ background:#fff3ea; border-color:#ff6a00; color:#e85d00; font-weight:600; }
        label.f{ display:block; font-size:12px; color:#5b6472; margin:12px 0 5px; }
        textarea{ width:100%; min-height:84px; padding:10px 12px; border:1px solid #e7eaf0; border-radius:9px; font-size:13px; resize:vertical; color:#1f2430; }
        select{ width:100%; padding:9px 10px; border:1px solid #e7eaf0; border-radius:9px; font-size:13px; background:#fff; color:#1f2430; }
        .hint{ font-size:11px; color:#8a8fa0; margin-top:5px; line-height:1.4; }
        textarea:focus, select:focus{ outline:none; border-color:#ff6a00; box-shadow:0 0 0 3px rgba(255,106,0,.12); }
        .grid2{ display:grid; grid-template-columns:1fr 1fr; gap:10px; }
        .ref{ display:flex; align-items:center; gap:10px; margin-top:10px; padding:8px; background:#f7f8fb; border-radius:9px; }
        .ref img{ width:44px; height:44px; object-fit:cover; border-radius:7px; }
        .ref .x{ margin-left:auto; cursor:pointer; color:#8a8fa0; background:none; border:none; }
        .drop{ margin-top:10px; border:1.5px dashed #d7dbe4; border-radius:10px; padding:12px; text-align:center; cursor:pointer; color:#8a8fa0; font-size:12px; background:#fafbfd; }
        .drop:hover, .drop.over{ border-color:#ff6a00; color:#e85d00; background:#fff6ee; }
        .drop .sym{ font-size:20px; display:block; margin-bottom:2px; }
        .tpl{ margin-top:10px; }
        .tpl .row{ display:flex; flex-wrap:wrap; gap:6px; }
        .tpl button{ font-size:12px; padding:5px 10px; border:1px solid #e7eaf0; border-radius:14px; background:#fff; cursor:pointer; color:#5b6472; }
        .tpl button:hover{ border-color:#ff6a00; color:#e85d00; background:#fff6ee; }
        .gen{ width:100%; margin-top:16px; padding:12px; border:none; border-radius:10px; background:#ff6a00; color:#fff; font-size:14px; font-weight:700; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; }
        .gen:hover{ background:#e85d00; }
        .gen:disabled{ opacity:.6; cursor:not-allowed; }
        .estimate{ font-size:12px; color:#5b6472; margin-top:8px; text-align:center; }
        .estimate b{ color:#e85d00; }
        .estimate .warn{ color:#c0392b; font-weight:600; }
        .status{ font-size:12px; color:#5b6472; margin-top:12px; min-height:16px; text-align:center; }
        .status.err{ color:#c0392b; }
        .result{ margin-top:12px; }
        .result img, .result video{ width:100%; border-radius:10px; background:#f0f1f5; }
        .result audio{ width:100%; }
        .spin{ width:26px; height:26px; margin:14px auto; border:3px solid #f0e2d6; border-top-color:#ff6a00; border-radius:50%; animation:sp .8s linear infinite; }
        @keyframes sp{ to{ transform:rotate(360deg); } }
        .dl{ display:inline-flex; align-items:center; gap:5px; margin-top:10px; color:#e85d00; text-decoration:none; font-size:13px; font-weight:600; }
        .expire{ margin-top:8px; font-size:11px; color:#c0392b; line-height:1.4; display:flex; align-items:flex-start; gap:5px; }
        .expire .sym{ font-size:14px; }
        .history{ display:flex; align-items:center; gap:6px; margin-top:14px; padding-top:12px; border-top:1px solid #eef1f6; color:#5b6472; text-decoration:none; font-size:12px; }
        .history:hover{ color:#e85d00; }
        .edits{ margin-top:14px; border-top:1px solid #eef1f6; padding-top:12px; }
        .edits .h{ font-size:11px; color:#8a8fa0; margin-bottom:8px; }
        .edits .row{ display:flex; flex-wrap:wrap; gap:6px; }
        .edits button{ display:inline-flex; align-items:center; gap:4px; font-size:12px; padding:5px 9px; border:1px solid #e7eaf0; border-radius:8px; background:#fff; cursor:pointer; color:#5b6472; }
        .edits button:hover{ border-color:#ff6a00; color:#e85d00; }
      </style>
      <div class="panel">
        <header>
          <img src="${chrome.runtime.getURL("icons/varoicon128.png")}" alt="Varo"/>
          <div><div class="t">Varo Extension</div><div class="s">Execution Engine</div></div>
          <div class="coins" id="coins" title="เหรียญคงเหลือ"><span class="sym">toll</span><span id="coinVal">—</span></div>
          <button class="close" id="close"><span class="sym">close</span></button>
        </header>
        <div class="body">
          <div class="seg" id="seg">
            <button data-kind="image"><span class="sym">palette</span> ภาพ</button>
            <button data-kind="video"><span class="sym">movie</span> วิดีโอ</button>
            <button data-kind="audio"><span class="sym">record_voice_over</span> เสียง</button>
          </div>
          <div class="ref" id="ref" style="display:none">
            <img id="refImg" alt="ref"/>
            <span style="font-size:12px;color:#5b6472">ใช้รูปนี้เป็นต้นแบบ</span>
            <button class="x" id="refX"><span class="sym">close</span></button>
          </div>
          <div class="drop" id="drop">
            <span class="sym">upload</span>อัปโหลดรูปต้นแบบ (ลากวาง หรือคลิก)
          </div>
          <input type="file" id="file" accept="image/*" style="display:none"/>
          <div class="tpl" id="tpl">
            <label class="f">เทมเพลตเริ่มต้น</label>
            <div class="row" id="tplRow"></div>
          </div>
          <label class="f">Prompt</label>
          <textarea id="prompt" placeholder="พิมพ์คำอธิบายภาพ/ฉาก/สคริปต์…"></textarea>
          <label class="f">โมเดล</label>
          <select id="model"></select>
          <div class="hint" id="modelHint"></div>
          <div class="grid2">
            <div id="qualityWrap"><label class="f">ความละเอียด</label><select id="quality"></select></div>
            <div id="aspectWrap"><label class="f">อัตราส่วน</label><select id="aspect"></select></div>
          </div>
          <div id="durationWrap"><label class="f">ความยาว</label><select id="duration"></select></div>
          <button class="gen" id="gen"><span class="sym">bolt</span> Generate</button>
          <div class="estimate" id="estimate"></div>
          <div class="status" id="status"></div>
          <div class="result" id="result"></div>
          <div class="edits" id="edits" style="display:none">
            <div class="h">บริการเพิ่มเติม — ส่งภาพไปเจนบนเว็บ Varoriya</div>
            <div class="row" id="editRow"></div>
          </div>
          <a class="history" id="history" href="https://varoriya.com/api-usage/" target="_blank" rel="noopener noreferrer">
            <span class="sym">history</span> ดูประวัติการเจนทั้งหมด
          </a>
        </div>
      </div>`;
    document.documentElement.appendChild(host);

    els = {
      close: shadow.getElementById("close"),
      coinVal: shadow.getElementById("coinVal"),
      seg: shadow.getElementById("seg"),
      ref: shadow.getElementById("ref"),
      refImg: shadow.getElementById("refImg"),
      refX: shadow.getElementById("refX"),
      drop: shadow.getElementById("drop"),
      file: shadow.getElementById("file"),
      tpl: shadow.getElementById("tpl"),
      tplRow: shadow.getElementById("tplRow"),
      prompt: shadow.getElementById("prompt"),
      model: shadow.getElementById("model"),
      modelHint: shadow.getElementById("modelHint"),
      quality: shadow.getElementById("quality"),
      qualityWrap: shadow.getElementById("qualityWrap"),
      aspect: shadow.getElementById("aspect"),
      aspectWrap: shadow.getElementById("aspectWrap"),
      duration: shadow.getElementById("duration"),
      durationWrap: shadow.getElementById("durationWrap"),
      gen: shadow.getElementById("gen"),
      status: shadow.getElementById("status"),
      estimate: shadow.getElementById("estimate"),
      result: shadow.getElementById("result"),
      edits: shadow.getElementById("edits"),
      editRow: shadow.getElementById("editRow")
    };

    els.close.addEventListener("click", close);
    els.refX.addEventListener("click", () => setRef(null));
    els.gen.addEventListener("click", generate);
    els.model.addEventListener("change", applyModelCaps);
    els.quality.addEventListener("change", computeEstimate);
    els.duration.addEventListener("change", computeEstimate);
    els.seg.addEventListener("click", (e) => {
      const k = e.target.closest("button")?.dataset.kind;
      if (k) setKind(k);
    });

    // Upload a reference image from the user's device (read as data URL so the
    // service worker can fetch() + presign-upload it just like a remote URL).
    els.drop.addEventListener("click", () => els.file.click());
    els.file.addEventListener("change", () => {
      const f = els.file.files?.[0];
      if (f) readFileAsRef(f);
      els.file.value = "";
    });
    ["dragover", "dragenter"].forEach((ev) =>
      els.drop.addEventListener(ev, (e) => {
        e.preventDefault();
        els.drop.classList.add("over");
      })
    );
    ["dragleave", "drop"].forEach((ev) =>
      els.drop.addEventListener(ev, (e) => {
        e.preventDefault();
        els.drop.classList.remove("over");
      })
    );
    els.drop.addEventListener("drop", (e) => {
      const f = e.dataTransfer?.files?.[0];
      if (f && f.type.startsWith("image/")) readFileAsRef(f);
    });

    // Starter templates -> fill the prompt box.
    els.tplRow.addEventListener("click", (e) => {
      const btn = e.target.closest("button");
      if (btn?.dataset.text) els.prompt.value = btn.dataset.text;
    });

    // build web-edit buttons once
    els.editRow.innerHTML = WEB_EDITS.map(
      (e) => `<button data-a="${e.a}"><span class="sym">${e.icon}</span> ${e.label}</button>`
    ).join("");
    els.editRow.addEventListener("click", (e) => {
      const a = e.target.closest("button")?.dataset.a;
      if (a && state.imageUrl && extAlive()) {
        chrome.runtime.sendMessage({ type: "varo:image-action", action: a, imageUrl: state.imageUrl });
      }
    });

    // live job updates from the service worker
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "varo:job-update" && msg.job?.id === state.jobId) onJob(msg.job);
    });
  }

  function modelsFor(kind) {
    return MODELS[kind] || MODELS.image;
  }
  function currentModel() {
    const list = modelsFor(state.kind);
    return list.find((m) => m.id === els.model.value) || list[0];
  }

  function fillModels() {
    const list = modelsFor(state.kind);
    const pref = state.pref[state.kind];
    els.model.innerHTML = list
      .map((m) => `<option value="${m.id}"${m.id === pref ? " selected" : ""}>${m.label}</option>`)
      .join("");
  }

  // Show/hide controls per kind + model — cut options a model doesn't support.
  function applyModelCaps() {
    const m = currentModel();
    const isAudio = state.kind === "audio";
    els.modelHint.textContent = m?.desc || "";

    const refOk = !isAudio && !!state.imageUrl && !!m?.ref;
    if (refOk) els.refImg.src = state.imageUrl;
    els.ref.style.display = refOk ? "" : "none";
    // Upload zone: available for image/video (models that can take a reference).
    els.drop.style.display = !isAudio && !!m?.ref && !state.imageUrl ? "" : "none";
    // Web-edit deep links need a public URL — hide for locally uploaded (data:) images.
    const remoteImg = !!state.imageUrl && /^https?:/i.test(state.imageUrl);
    els.edits.style.display = !isAudio && remoteImg ? "" : "none";

    if (m?.qualities?.length) {
      const cur = els.quality.value;
      els.quality.innerHTML = m.qualities.map((q) => `<option value="${q}">${q}</option>`).join("");
      els.quality.value = m.qualities.includes(cur) ? cur : m.dq || m.qualities[0];
      els.qualityWrap.style.display = "";
    } else {
      els.qualityWrap.style.display = "none";
    }

    if (m?.aspects?.length && !isAudio) {
      const cur = els.aspect.value;
      els.aspect.innerHTML = m.aspects.map((a) => `<option value="${a}">${a}</option>`).join("");
      els.aspect.value = m.aspects.includes(cur) ? cur : m.aspects[0];
      els.aspectWrap.style.display = "";
    } else {
      els.aspectWrap.style.display = "none";
    }

    if (m?.durations?.length) {
      const ds = m.durations.map(String);
      const cur = els.duration.value;
      els.duration.innerHTML = ds.map((d) => `<option value="${d}">${d}s</option>`).join("");
      els.duration.value = ds.includes(cur) ? cur : ds.includes("5") ? "5" : ds[0];
      els.durationWrap.style.display = "";
    } else {
      els.durationWrap.style.display = "none";
    }

    computeEstimate();
  }

  function setKind(kind) {
    state.kind = kind;
    [...els.seg.children].forEach((b) => b.classList.toggle("on", b.dataset.kind === kind));
    fillModels();
    fillTemplates();
    applyModelCaps();
  }

  function setRef(url) {
    state.imageUrl = url;
    applyModelCaps();
  }

  function readFileAsRef(file) {
    const reader = new FileReader();
    reader.onload = () => setRef(reader.result);
    reader.readAsDataURL(file);
  }

  // --- Coins: balance + per-request cost estimate ---
  function setCoins(n) {
    state.coins = typeof n === "number" ? n : state.coins;
    if (els.coinVal) els.coinVal.textContent = state.coins == null ? "—" : state.coins.toLocaleString();
    computeEstimate();
  }

  function requestBalance() {
    if (!extAlive()) return;
    chrome.runtime.sendMessage({ type: "varo:balance" }).then((r) => {
      if (r?.ok && typeof r.coins === "number") setCoins(r.coins);
    }).catch(() => {});
  }

  function requestPricing() {
    if (!extAlive()) return;
    chrome.runtime.sendMessage({ type: "varo:pricing" }).then((r) => {
      if (r?.ok && Array.isArray(r.models)) {
        state.pricing = r.models;
        computeEstimate();
      }
    }).catch(() => {});
  }

  function computeEstimate() {
    if (!els.estimate) return;
    const m = currentModel();
    const p = state.pricing.find((x) => x.model === els.model.value);
    if (!p || !p.rates) {
      els.estimate.textContent = "";
      return;
    }
    const rates = p.rates;
    const q = m?.qualities?.length && els.quality.value ? els.quality.value : p.default_quality;
    let rate = rates[q];
    if (rate == null) rate = Object.values(rates)[0];
    if (rate == null) {
      els.estimate.textContent = "";
      return;
    }
    let coins = rate;
    if (p.unit === "second") {
      if (!m?.durations?.length) {
        // Length unknown at submit (e.g. audio) — show the per-second rate.
        els.estimate.innerHTML = `ประมาณ <b>${rate.toLocaleString()}</b> coins/วินาที`;
        return;
      }
      const dur = parseInt(els.duration.value, 10) || m.durations[0];
      coins = rate * dur;
    }
    const enough = state.coins == null || coins <= state.coins;
    els.estimate.innerHTML =
      `ใช้ประมาณ <b>${coins.toLocaleString()}</b> coins` +
      (p.unit === "second" ? ` (${rate}/วิ)` : "") +
      (enough ? "" : ` — <span class="warn">เหรียญคงเหลือไม่พอ</span>`);
  }

  function fillTemplates() {
    const list = TEMPLATES[state.kind] || [];
    els.tplRow.innerHTML = list
      .map((t) => `<button type="button" data-text="${t.text.replace(/"/g, "&quot;")}">${t.label}</button>`)
      .join("");
    els.tpl.style.display = list.length ? "" : "none";
  }

  function resetResult() {
    els.result.innerHTML = "";
    els.status.textContent = "";
    els.status.classList.remove("err");
  }

  async function generate() {
    const m = currentModel();
    const model = els.model.value;
    const prompt = els.prompt.value.trim();
    const useRef = !!state.imageUrl && !!m?.ref && state.kind !== "audio";
    if (!prompt && !useRef) {
      els.status.textContent = "ใส่ prompt ก่อนนะครับ";
      els.status.classList.add("err");
      return;
    }
    resetResult();
    els.gen.disabled = true;
    els.result.innerHTML = `<div class="spin"></div>`;
    els.status.textContent = "กำลังส่งงาน…";

    const payload = { model, prompt };
    if (useRef) payload.imageUrl = state.imageUrl;
    if (m?.qualities?.length) payload.quality = els.quality.value;
    if (m?.aspects?.length && els.aspect.value && els.aspect.value !== "auto") {
      payload.aspect_ratio = els.aspect.value;
    }
    if (m?.durations?.length) {
      payload.options = { duration: parseInt(els.duration.value, 10) || m.durations[0] };
    }

    const res = extAlive()
      ? await chrome.runtime
          .sendMessage({ type: "varo:generate", kind: state.kind, payload })
          .catch(() => ({ ok: false }))
      : { ok: false, error: "extension_reloaded" };

    if (!res || res.ok === false) {
      els.gen.disabled = false;
      els.result.innerHTML = "";
      els.status.classList.add("err");
      els.status.textContent =
        res?.code === "MISSING_API_KEY"
          ? "ยังไม่ได้เชื่อมบัญชี — เปิดหน้าตั้งค่าเพื่อเชื่อม Varoriya"
          : res?.error === "extension_reloaded"
          ? "ส่วนเสริมเพิ่งรีโหลด — โปรดรีเฟรชหน้าเว็บแล้วลองใหม่"
          : "เริ่มงานไม่สำเร็จ: " + (res?.error || "unknown");
      return;
    }
    state.jobId = res.jobId;
    if (typeof res.coinsRemaining === "number") setCoins(res.coinsRemaining);
    els.status.textContent = "กำลังประมวลผล… (ทำงานเบื้องหลัง)";
  }

  function onJob(job) {
    const st = (job.state || "").toLowerCase();
    if (["done", "succeeded", "completed"].includes(st) && job.result_url) {
      els.gen.disabled = false;
      els.status.textContent = "เสร็จแล้ว ✓";
      const url = job.result_url;
      let media;
      if (state.kind === "video") media = `<video src="${url}" controls playsinline></video>`;
      else if (state.kind === "audio") media = `<audio src="${url}" controls></audio>`;
      else media = `<img src="${url}" alt="result"/>`;
      els.result.innerHTML = `${media}<a class="dl" href="${url}" download target="_blank"><span class="sym">download</span> ดาวน์โหลด</a><div class="expire"><span class="sym">schedule</span> ระบบจะลบไฟล์อัตโนมัติภายใน 24 ชั่วโมง โปรดดาวน์โหลดเก็บไว้</div>`;
    } else if (["failed", "error", "canceled", "timeout"].includes(st)) {
      els.gen.disabled = false;
      els.result.innerHTML = "";
      els.status.classList.add("err");
      els.status.textContent = "งานไม่สำเร็จ: " + (job.error || st);
    }
  }

  function open(opts = {}) {
    if (!host) build();
    const kind = opts.kind === "voice" ? "audio" : opts.kind || "image";
    state.imageUrl = opts.imageUrl || null;
    setKind(kind); // fills models + applyModelCaps (reads state.imageUrl)
    // optional overrides (e.g. AiPASS embed -> video / h3 / auto / 768P)
    if (opts.model && [...els.model.options].some((o) => o.value === opts.model)) {
      els.model.value = opts.model;
      applyModelCaps();
    }
    if (opts.quality && [...els.quality.options].some((o) => o.value === opts.quality)) {
      els.quality.value = opts.quality;
    }
    if (opts.aspect && [...els.aspect.options].some((o) => o.value === opts.aspect)) {
      els.aspect.value = opts.aspect;
    }
    els.prompt.value = opts.prompt || "";
    state.jobId = null;
    resetResult();
    els.gen.disabled = false;
    requestBalance();
    requestPricing();
    requestAnimationFrame(() => host.classList.add("open"));
    els.prompt.focus();
  }

  function close() {
    if (host) host.classList.remove("open");
  }

  window.VaroStudio = { open, close };
})();
